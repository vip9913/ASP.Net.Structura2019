-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               5.7.21-log - MySQL Community Server (GPL)
-- Операционная система:         Win64
-- HeidiSQL Версия:              9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Дамп структуры базы данных sprav
CREATE DATABASE IF NOT EXISTS `sprav` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `sprav`;

-- Дамп структуры для таблица sprav.departments
CREATE TABLE IF NOT EXISTS `departments` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Department` varchar(255) DEFAULT NULL,
  `Group` int(255) DEFAULT NULL,
  `Level` int(255) DEFAULT NULL,
  `Description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Дамп данных таблицы sprav.departments: ~6 rows (приблизительно)
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
REPLACE INTO `departments` (`Id`, `Department`, `Group`, `Level`, `Description`) VALUES
	(1, 'Администрация', NULL, NULL, 'сотрудники управления'),
	(2, 'Бухгалтерия', NULL, NULL, 'расчетный отдел'),
	(3, 'IT-отдел', NULL, NULL, 'инженера и программисты'),
	(4, 'Дохтора', NULL, NULL, 'те кому не платят'),
	(5, 'отдел разработки', NULL, NULL, 'инженера программисты'),
	(8, 'отдел сопровождения', NULL, NULL, 'технические специалисты первой линии поддержки');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;

-- Дамп структуры для таблица sprav.employees
CREATE TABLE IF NOT EXISTS `employees` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `DepartmentId` int(11) DEFAULT NULL,
  `FirstName` varchar(30) DEFAULT NULL,
  `SecondName` varchar(30) DEFAULT NULL,
  `LastName` varchar(50) DEFAULT NULL,
  `BirthdayDate` datetime NOT NULL,
  `OrderDate` datetime NOT NULL,
  `Floor` varchar(1) DEFAULT NULL,
  `Telephone` varchar(10) DEFAULT NULL,
  `Email` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `FK_employees_departments` (`DepartmentId`),
  CONSTRAINT `FK_employees_departments` FOREIGN KEY (`DepartmentId`) REFERENCES `departments` (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Дамп данных таблицы sprav.employees: ~3 rows (приблизительно)
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
REPLACE INTO `employees` (`Id`, `DepartmentId`, `FirstName`, `SecondName`, `LastName`, `BirthdayDate`, `OrderDate`, `Floor`, `Telephone`, `Email`) VALUES
	(1, 1, 'Петр', 'Ильич', 'Васечкин', '2000-10-22 00:00:00', '2018-10-11 11:24:14', 'М', '55-66-77', NULL),
	(2, 2, 'Олег', 'Иванович', 'Петров', '2003-10-22 00:00:00', '2018-10-11 13:15:22', 'М', '55-00-55', NULL),
	(3, 2, 'Олег', 'Иванович', 'Газманов', '2003-11-22 00:00:00', '2018-10-11 13:15:41', 'М', '50-66-70', NULL),
	(10, 1, 'Сергей', 'Васильевич', 'Иванов', '1950-01-01 00:00:00', '2000-01-09 00:00:00', 'M', '11-22-33', 'hanter@mail.ru');
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
